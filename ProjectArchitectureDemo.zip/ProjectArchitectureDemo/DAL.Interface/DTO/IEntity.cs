﻿namespace DAL.Interface.DTO
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
